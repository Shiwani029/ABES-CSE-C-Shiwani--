// Components/login.jsx
function Login() {
  return (
    <div>
      <h2>Login Page</h2>
      <form>
        <input type="text" placeholder="Username" />
        <input type="password" placeholder="Password" />
        <button>Login</button>
      </form>
    </div>
  )
}
export default Login
